# Full planning validation and test evaluation

Updated: 2026-10-26T20:19:44.014221+08:00

Frozen native best_planning checkpoints selected during training. Test never selects models. Shared-GPU timing is not a dedicated latency benchmark. Offline collision metrics are not closed-loop safety claims.

| Arm | Split | Epoch | Samples | Valid | ADE m | FDE m | Required coverage | SHORT recall |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | val | 3 | 1451 | 1.0000 | 1.1644 | 2.5397 | 0.9995 | 0.5000 |
| action | val | 5 | 1451 | 0.9759 | 0.7572 | 1.6309 | 0.9761 | 0.5000 |
| assignment | val | 5 | 1451 | 1.0000 | 1.6951 | 3.9511 | 0.9995 | 0.4091 |
| risk | val | 5 | 1451 | 1.0000 | 1.9239 | 4.4752 | 0.9991 | 0.5000 |
| combined | val | 5 | 1451 | 0.9759 | 0.8181 | 1.8185 | 0.9756 | 0.4091 |
| baseline_readout | val | 5 | 1451 | 1.0000 | 1.3195 | 3.0023 | 0.9995 | 0.5000 |
| baseline | test | 3 | 1522 | 1.0000 | 1.4927 | 3.1827 | 0.9987 | 0.0500 |
| action | test | 5 | 1522 | 0.9731 | 0.8223 | 1.6978 | 0.9735 | 0.0750 |
| assignment | test | 5 | 1522 | 1.0000 | 1.8103 | 3.8512 | 1.0000 | 0.1250 |
| risk | test | 5 | 1522 | 1.0000 | 2.1839 | 4.9578 | 0.9978 | 0.0250 |
| combined | test | 5 | 1522 | 0.9731 | 0.7938 | 1.6385 | 0.9761 | 0.0750 |
| baseline_readout | test | 5 | 1522 | 1.0000 | 1.6531 | 3.4353 | 0.9969 | 0.0250 |
