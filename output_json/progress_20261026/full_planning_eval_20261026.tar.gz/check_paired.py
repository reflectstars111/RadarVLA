import importlib.util,json,tempfile
from pathlib import Path
r=Path('/storage/ssd/metaiot_guest/luxinlan_radarvla_cache/evaluations/full_planning_20261026');spec=importlib.util.spec_from_file_location('f',r/'finalize_reports.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
truth={'x':dict(ego=dict(future_xy=[[0,0]]*6),future_times_s=[.5,1,1.5,2,2.5,3],local_agent_risk_labels={'a':dict(pcol=[1,1,1],pcol_mask=[True]*3)})}
with tempfile.TemporaryDirectory(dir=r) as temp:
 jobs=[]
 for split in ['val','test']:
  for arm in ['a','b']:
   out=Path(temp)/split/arm;out.mkdir(parents=True)
   points=[[0,0]]*6 if arm=='a' else [[1,0]]*2
   times=[.5,1,1.5,2,2.5,3] if arm=='a' else [.5,1]
   row=dict(sample_id='x',plan=dict(valid=True,ego_trajectory=points,ego_times_s=times))
   (out/'predictions.jsonl').write_text(json.dumps(row))
   jobs.append(dict(split=split,arm=arm,output=str(out)))
 result=m.paired_comparison(dict(jobs=jobs),truth)
 for group in result.values():
  assert group['common_points']==2 and group['common_final_samples']==0
  assert group['arms']['a']['ade_m']==0. and group['arms']['b']['ade_m']==1.
  assert group['arms']['a']['fde_3s_m'] is None
 print('PASS: paired metrics use identical coverage intersection; omitted3s endpoints never become successful FDE')
