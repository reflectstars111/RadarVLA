import importlib.util
from pathlib import Path
r=Path('/storage/ssd/metaiot_guest/luxinlan_radarvla_cache/evaluations/full_planning_20261026')
spec=importlib.util.spec_from_file_location('finalizer',r/'finalize_reports.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
record=dict(sample_id='sample',ego=dict(future_xy=[[0.,0.]]*6,future_valid=[True]*6),future_times_s=[.5,1.,1.5,2.,2.5,3.],agents=[dict(id='hazard',position=[1.,0.]),dict(id='unknown',position=[10.,0.])],local_agent_risk_labels=dict(hazard=dict(pcol=[1,1,1],pcol_mask=[True]*3),unknown=dict(pcol=[0,0,0],pcol_mask=[False]*3)))
row=dict(sample_id='sample',risk=[.1,.1,.1],generated_tokens=0,detections=[dict(position_m=[1.,0.])],plan=dict(valid=True,mode='short',ego_times_s=[.5,1.],ego_trajectory=[[0.,0.],[0.,0.]]))
out,details=m.supplemental([row],{'sample':record})
assert out['total_targets']==2 and out['total_detected']==1
assert out['hazard_detection']['2.0']['targets']==1 and out['hazard_detection']['2.0']['recall']==1.
assert out['hazard_detection']['2.0']['missed_target_and_risk_below_0p5']==0
assert out['trajectory_horizons_s']['1.0']['ego_point_coverage']==1.
assert out['trajectory_horizons_s']['1.0']['ego_final_horizon_fde_m']==0.
assert out['trajectory_horizons_s']['3.0']['ego_final_horizon_fde_m'] is None
assert out['trajectory_horizons_s']['3.0']['ego_point_coverage']==1/3
row['detections']=[]
out,_=m.supplemental([row],{'sample':record})
assert out['hazard_detection']['2.0']['missed_target_and_risk_below_0p5']==1
print('PASS: matching, unknown labels, missed hazard/risk joint diagnosis, short-plan horizon FDE and coverage')
